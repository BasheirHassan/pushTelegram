<?php
/*
 * Basheir
 * 1-11-2017
 *  Push Telegram
 */
$_['heading_title'] = 'Push Telegram';
$_['entry_description'] = 'In order to use push messages you need ';
$_['entry_app_key'] = 'Application API Key';
$_['entry_user_key'] = 'PushTelegram User Key';
$_['entry_send_order_alert'] = 'Send alert on new order';
$_['error_no_key'] = 'No User Key or Api Key entered';
$_['text_module']      = 'Modules';
$_['message_sent_success'] = 'Message sent succesfully';
$_['message_sent_error'] = 'Message couldnt be sent, please check your details';
$_['text_edit'] = 'Edit Push Telegram Notification Settings';
?>