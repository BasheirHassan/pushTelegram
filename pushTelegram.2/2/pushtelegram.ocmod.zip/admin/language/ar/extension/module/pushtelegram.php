<?php
/*
 * Basheir
 * 1-11-2017
 *  Push Telegram
 */
$_['heading_title'] = 'Push Telegram';
$_['entry_description'] = 'ضبط الاعدادات لارسال التنبيهات';
$_['entry_app_key'] = 'Application BOT_TOKEN';
$_['entry_user_key'] = 'PushTelegram Chat ID';
$_['entry_send_order_alert'] = 'ارسال تنبيه عند طلب جديد';
$_['error_no_key'] = 'لم تقم بادخال - BOT_TOKEN';
$_['text_module']      = 'Modules';
$_['entry_add_amount_total']      = 'اضافة مجموع النتجات';
$_['entry_add_products']      = 'اضافة المنتجات اللي تم شرائها';
$_['message_sent_success'] = 'تم ارساله التنبيه بنجاح';
$_['message_sent_error'] = 'لايمكن ارسال اتنبيه - الرجاء التحقق من الاعدادات';
$_['text_edit'] = 'تعديل تنبيهات / Push Telegram';
$_['header_customer_message'] = ' اعدادات المستخدم';
$_['entry_send_new_customer_alert'] = 'تنبيه عند تسجيل مستخدم جديد';
$_['entry_add_customer_name'] = 'اضافة اسم المستخدم للتنبيه';

?>